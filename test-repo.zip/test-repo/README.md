```
mkdir build
cd build
```

версия Visual Studio может отличаться
```
cmake .. -G "Visual Studio 16 2019"
```
